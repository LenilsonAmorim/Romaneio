# Romaneio App

APK Android que abre a versão online do Organizador em WebView.

- Instala uma vez.
- A planilha é escolhida dentro do app.
- O sistema web faz a análise e mostra a rota na própria tela.
- Ao voltar/abrir o app, ele recarrega o site para pegar as alterações mais recentes.
- O gesto de puxar para baixo também atualiza.
- O seletor de arquivos do Android é compatível com XLSX/XLS/CSV.

URL configurada:
https://lenilsonamorim.github.io/Romaneio/Romaneio/Organizador/

O workflow `.github/workflows/build-apk.yml` gera o APK no GitHub Actions.
