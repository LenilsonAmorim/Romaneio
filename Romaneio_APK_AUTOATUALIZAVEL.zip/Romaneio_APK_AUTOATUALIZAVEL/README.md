# Romaneio APK — atualização automática

Este projeto não embute uma cópia do site.

O aplicativo abre diretamente:
https://lenilsonamorim.github.io/Romaneio/

Assim, alterações publicadas no GitHub Pages ficam disponíveis no aplicativo sem precisar gerar outro APK.

O WebView usa `LOAD_NO_CACHE` e limpa o cache ao iniciar para evitar mostrar uma versão antiga.
