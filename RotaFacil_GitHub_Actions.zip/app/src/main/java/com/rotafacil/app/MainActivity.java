package com.rotafacil.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;

import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int SAVE_FILE_REQUEST = 1002;

    private ValueCallback<Uri[]> filePathCallback;
    private byte[] pendingFileBytes;
    private String pendingFileName = "rota-atualizada.xlsx";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView webView = new WebView(this);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());

        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams fileChooserParams) {

                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }

                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        new String[] {
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel",
                                "text/csv",
                                "application/csv"
                        }
                );

                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public class AndroidBridge {

        @JavascriptInterface
        public void saveBase64File(String filename, String base64) {
            try {
                pendingFileName = filename;
                pendingFileBytes = Base64.decode(base64, Base64.DEFAULT);

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                );
                intent.putExtra(Intent.EXTRA_TITLE, filename);

                startActivityForResult(intent, SAVE_FILE_REQUEST);
            } catch (Exception e) {
                pendingFileBytes = null;
            }
        }
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode == FILE_CHOOSER_REQUEST) {

            if (filePathCallback == null) {
                return;
            }

            Uri[] results = null;

            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();

                if (uri != null) {
                    results = new Uri[] { uri };
                }
            }

            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }

        if (requestCode == SAVE_FILE_REQUEST) {

            if (resultCode == RESULT_OK
                    && data != null
                    && data.getData() != null
                    && pendingFileBytes != null) {

                try {
                    Uri uri = data.getData();

                    OutputStream out =
                            getContentResolver()
                                    .openOutputStream(uri);

                    if (out != null) {
                        out.write(pendingFileBytes);
                        out.flush();
                        out.close();
                    }

                    // Open the saved XLSX in the spreadsheet app installed on the phone.
                    Intent openIntent = new Intent(Intent.ACTION_VIEW);
                    openIntent.setDataAndType(
                            uri,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    );
                    openIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivity(openIntent);
                    } catch (Exception ignoredOpen) {
                        // File is still saved even if no spreadsheet app is installed.
                    }

                } catch (Exception ignored) {
                }
            }

            pendingFileBytes = null;
        }
    }
}
