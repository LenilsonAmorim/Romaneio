# Romaneios

Roteirizador Android por regiões, quadras, ruas e referências mistas.

## Roteirização
- A planilha pode conter várias regiões.
- O app identifica todas as regiões cadastradas.
- Cada região tem sua própria ordem manual.
- A coluna **Parada** mostra a ordem real da rota.
- A mesma referência mantém as entregas juntas.
- Saída e retorno podem ser configurados por região.
- Linhas sem região ficam vermelhas no topo.
- Possíveis correspondências/referências faltantes ficam cinza no topo da própria região.
- Não há histórico.
