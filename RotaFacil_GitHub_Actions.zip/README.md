# Rota Fácil

Projeto Android preparado para compilação automática pelo GitHub Actions.

## Regras atuais
- Saída e retorno: E2
- Coordenadas da planilha: ignoradas
- A: A1-A7
- B: B1-B12
- C: C1-C2
- D: D1-D12
- E: E1-E16
- F: F1-F11
- G: G1-G13
- H: H1-H4
- I: I1-I10

O próximo passo de desenvolvimento é preencher a malha de conexões físicas entre as quadras com base nos mapas enviados.
