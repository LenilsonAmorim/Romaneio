# Romaneios

Roteirizador Android por regiões, quadras, ruas e referências mistas.

A identificação de quadras aceita formatos como A7, A 7, A-7, Quadra A7,
Qd A 7, Quadra G 2, Quadra I 02 e I-3. Se Jarbas estiver presente e a
quadra estiver cadastrada, a entrega entra na rota normal. Cinza é reservado
para conferência quando a região é reconhecida, mas a referência não é
confirmada. Vermelho é usado quando nenhuma região é identificada.

A ordem da rota segue exatamente o cadastro de cada região.
