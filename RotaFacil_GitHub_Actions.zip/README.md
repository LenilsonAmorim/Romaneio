# Rota Fácil

APK Android com GitHub Actions.

## Como usar
1. Abra o app.
2. Selecione sua planilha `.xlsx`, `.xls` ou `.csv`.
3. Escolha a coluna que contém o endereço (o app tenta detectar automaticamente).
4. Deixe `E2` como saída/retorno ou altere se necessário.
5. Toque em **Fazer rota**.
6. Toque em **Baixar planilha roteirizada**.

A planilha final mantém todas as linhas e acrescenta `Parada` e `Quadra Rota`.

## Regras atuais
- Saída/retorno: E2
- Latitude/longitude: ignoradas
- A: A1-A7
- B: B1-B12
- C: C1-C2
- D: D1-D12
- E: E1-E16
- F: F1-F11
- G: G1-G13
- H: H1-H4
- I: I1-I10

Ciclo atual: E → F → G → H → I → A → B → C → D → E.
