# Rota Fácil

Roteirizador Android por regiões, quadras, ruas e referências mistas.

## Recursos
- Uma planilha pode conter várias regiões.
- O app pesquisa todas as regiões cadastradas.
- Cada região tem cor própria.
- Cada região pode ter aliases (ex.: Jarbas, Jabas).
- A ordem da rota é manual e pode misturar quadras, ruas e números.
- Não usa ordem alfabética para inventar rota.
- Linhas sem região ficam vermelhas no topo.
- Linhas com região provável/quadra ou referência não confirmada ficam cinza no topo da própria região.
- O cadastro pode ser editado dentro do app.
- Há uma tela de teste para conferir como um endereço será interpretado.
- A planilha original não é alterada; uma nova planilha é gerada.
- Não inclui histórico, conforme solicitado.
- Depois de salvar a planilha, o Android tenta abri-la no aplicativo de planilhas instalado.
