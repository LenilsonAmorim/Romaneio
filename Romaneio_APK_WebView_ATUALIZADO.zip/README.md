# Romaneio APK WebView — atualizado

- Nome: Romaneio
- Ícone: versões PNG redimensionadas a partir do ícone de 512px, com a margem externa reduzida para ocupar melhor o espaço.
- Site carregado pelo APK: https://lenilsonamorim.github.io/Romaneio/
- WebView configurado para não usar cache (`LOAD_NO_CACHE`), para buscar a versão mais recente do site.
- O APK não contém uma cópia da lógica do site: `index.html`, `app.js`, `viewer.js`, `styles.css` e demais páginas continuam vindo do site.
- Se o site for alterado, o conteúdo aberto pelo APK será atualizado na próxima abertura/recarga, desde que haja internet.
- Seletor de arquivos habilitado para XLSX/XLS/CSV.
