package com.lenilson.romaneio;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.view.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {
    private static final String URL =
        "https://lenilsonamorim.github.io/Romaneio/Romaneio/Organizador/";
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SwipeRefreshLayout refresh = new SwipeRefreshLayout(this);
        web = new WebView(this);
        refresh.addView(web, new SwipeRefreshLayout.LayoutParams(-1,-1));
        setContentView(refresh);

        refresh.setOnRefreshListener(() -> {
            web.reload();
            web.postDelayed(() -> refresh.setRefreshing(false), 900);
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        web.setBackgroundColor(Color.WHITE);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb,
                    FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;
                Intent i = params.createIntent();
                try { startActivityForResult(i, 1001); }
                catch (Exception e) {
                    uploadCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl(URL);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1001 && uploadCallback != null) {
            Uri[] result = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getData() != null) result = new Uri[]{data.getData()};
                else if (data.getClipData() != null) {
                    int n=data.getClipData().getItemCount();
                    result=new Uri[n];
                    for(int i=0;i<n;i++) result[i]=data.getClipData().getItemAt(i).getUri();
                }
            }
            uploadCallback.onReceiveValue(result);
            uploadCallback=null;
        }
        super.onActivityResult(requestCode,resultCode,data);
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.reload(); // busca a versão atual do site
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}