package com.lenilson.romaneio;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
 private static final String SITE="https://lenilsonamorim.github.io/Romaneio/";
 private WebView webView;
 @SuppressLint("SetJavaScriptEnabled")
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  webView=new WebView(this);
  setContentView(webView);
  WebSettings s=webView.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setDatabaseEnabled(true);
  s.setLoadsImagesAutomatically(true);
  s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  webView.setWebViewClient(new WebViewClient());
  webView.loadUrl(SITE);
 }
 @Override public void onBackPressed(){
  if(webView.canGoBack()) webView.goBack(); else super.onBackPressed();
 }
}
