# Romaneio APK — FINAL

Versão final do APK WebView do Romaneio.

- Nome: Romaneio
- Ícone: versão grande e nítida baseada na imagem fornecida.
- Site carregado: https://lenilsonamorim.github.io/Romaneio/
- Internet habilitada para o site e Supabase.
- Seletor de arquivos habilitado para XLSX/XLS/CSV.
- Não contém cópia da lógica do site.
- As futuras alterações de app.js, viewer.js, index.html e styles.css continuam sendo feitas no site.

Para gerar o APK no GitHub Actions, use o workflow existente que procura
`Romaneio_APK_WebView.zip`.
