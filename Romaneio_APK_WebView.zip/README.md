# Romaneio APK WebView

Aplicativo Android mínimo que abre diretamente o site:
https://lenilsonamorim.github.io/Romaneio/

Não contém app.js, viewer.js ou styles.css dentro do APK.
O site é a fonte da lógica e da interface.

Esta versão não usa Kotlin, AndroidX AppCompat ou AndroidX WebKit,
evitando conflitos de classes Kotlin no build.
