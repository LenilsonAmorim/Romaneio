package com.lenilson.romaneio;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SplashActivity extends Activity {
    private static final long SPLASH_TIME_MS = 1500L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(7, 26, 58));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.lenilson.romaneio.R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int size = (int) (getResources().getDisplayMetrics().density * 210);
        root.addView(logo, new LinearLayout.LayoutParams(size, size));
        setContentView(root);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }, SPLASH_TIME_MS);
    }
}
