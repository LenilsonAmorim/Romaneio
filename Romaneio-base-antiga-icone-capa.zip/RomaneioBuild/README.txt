ROMANEIO - BUILD FINAL

Base funcional:
https://lenilsonamorim.github.io/Romaneio/Romaneio/Organizador/

Alterações somente no wrapper:
- ícone maior e mais nítido;
- capa de abertura centralizada;
- 1,5 segundo de capa;
- suporte ao seletor de planilha;
- botão voltar do Android preservado no WebView.

O conteúdo e os comandos do site não foram alterados.
