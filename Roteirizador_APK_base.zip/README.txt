ROTEIRIZADOR - APP ANDROID

Este projeto é uma base de aplicativo Android (WebView) para o Roteirizador.
Ele abre o site remoto dentro do aplicativo, permitindo que as alterações
do site sejam usadas pelo app sem precisar publicar um novo APK para cada
alteração de HTML/CSS/JS.

SITE:
https://lenilsonamorim.github.io/Romaneio/Romaneio/

PERMISSÕES PREPARADAS:
- INTERNET
- ACCESS_FINE_LOCATION
- ACCESS_COARSE_LOCATION
- POST_NOTIFICATIONS
- WAKE_LOCK

OBSERVAÇÃO:
O Android exige que o usuário conceda localização/notificações quando
necessário. O app não pode forçar o GPS do aparelho a permanecer ligado.
Para mudanças de código nativo do APK, será necessário gerar uma nova versão.
