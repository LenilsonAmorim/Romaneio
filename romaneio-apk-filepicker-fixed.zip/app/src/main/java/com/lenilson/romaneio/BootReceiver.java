package com.lenilson.romaneio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        android.content.SharedPreferences p =
            context.getSharedPreferences("tracking", Context.MODE_PRIVATE);
        if (p.getBoolean("stopped", false)) return;
        if (p.getString("id", "").trim().isEmpty()) return;
        Intent service = new Intent(context, LocationService.class);
        service.setAction(LocationService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
        else context.startService(service);
    }
}
