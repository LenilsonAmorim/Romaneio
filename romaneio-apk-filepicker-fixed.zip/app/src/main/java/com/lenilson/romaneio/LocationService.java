package com.lenilson.romaneio;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.*;

public class LocationService extends Service {
    public static final String ACTION_STOP = "com.lenilson.romaneio.STOP_LOCATION";
    private static final int NOTIFICATION_ID = 4101;
    private Handler handler;
    private android.location.LocationManager lm;
    private android.location.LocationListener listener;
    private boolean running = false;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        lm = (android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (ACTION_STOP.equals(intent != null ? intent.getAction() : null)) {
            stopTracking();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, notification());
        startTracking();
        return START_STICKY;
    }

    private void startTracking() {
        if (running) return;
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }
        try {
            listener = new android.location.LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    getSharedPreferences("location", MODE_PRIVATE).edit()
                        .putString("lat", String.valueOf(location.getLatitude()))
                        .putString("lng", String.valueOf(location.getLongitude()))
                        .putLong("time", System.currentTimeMillis())
                        .apply();
                }
            };
            lm.requestLocationUpdates(android.location.LocationManager.GPS_PROVIDER, 10000L, 10f, listener, Looper.getMainLooper());
            running = true;
        } catch (SecurityException ignored) {
            stopSelf();
        }
    }

    private Notification notification() {
        Intent stop = new Intent(this, LocationService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 77, stop,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 78, open,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        return new Notification.Builder(this, "location")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Romaneio — Rastreamento ativo")
            .setContentText("Localização sendo compartilhada")
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(new Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "PARAR LOCALIZAÇÃO", pi).build())
            .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("location", "Rastreamento de localização",
                NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Rastreamento do entregador");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private void stopTracking() {
        try { if (lm != null && listener != null) lm.removeUpdates(listener); } catch(Exception ignored) {}
        running = false;
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        try { if (lm != null && listener != null) lm.removeUpdates(listener); } catch(Exception ignored) {}
        running=false;
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
