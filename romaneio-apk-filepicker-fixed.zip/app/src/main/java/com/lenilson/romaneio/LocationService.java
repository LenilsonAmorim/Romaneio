package com.lenilson.romaneio;

import android.app.*;
import android.content.*;
import android.os.*;
import android.location.Location;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class LocationService extends Service {
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL = "romaneio_tracking";
    private static final String SUPABASE_URL = "https://kfjalmwlbgayyogiaanx.supabase.co";
    private static final String SUPABASE_KEY = "sb_publishable_GXokf74ebXiWSQpv6iuWrg_DfY0cPfH";
    private static final String TABLE = "entregadores_localizacao";

    private FusedLocationProviderClient fused;
    private LocationCallback callback;
    private String nome="", id="", pedido="";
    private long lastSent=0;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, notification("Ativo • aguardando GPS"));
        fused = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if(intent != null){
            nome = intent.getStringExtra("nome");
            id = intent.getStringExtra("id");
            pedido = intent.getStringExtra("pedido");
        }
        startLocation();
        return START_STICKY;
    }

    private void startLocation() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }

        LocationRequest req = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 8000L)
                .setMinUpdateIntervalMillis(5000L)
                .setWaitForAccurateLocation(false)
                .build();

        callback = new LocationCallback() {
            @Override public void onLocationResult(LocationResult result) {
                Location l = result.getLastLocation();
                if(l != null) sendLocation(l);
            }
        };
        fused.requestLocationUpdates(req, callback, Looper.getMainLooper());
    }

    private void sendLocation(Location l) {
        long now=System.currentTimeMillis();
        if(now-lastSent < 5000) return;
        lastSent=now;
        updateNotification("🟢 Online • " + String.format(java.util.Locale.US, "%.5f, %.5f", l.getLatitude(), l.getLongitude()));

        new Thread(() -> {
            try {
                URL url = new URL(SUPABASE_URL + "/rest/v1/" + TABLE);
                HttpURLConnection c=(HttpURLConnection)url.openConnection();
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("apikey", SUPABASE_KEY);
                c.setRequestProperty("Authorization", "Bearer " + SUPABASE_KEY);
                c.setRequestProperty("Content-Type","application/json");
                c.setRequestProperty("Prefer","resolution=merge-duplicates,return=minimal");

                JSONObject o=new JSONObject();
                o.put("entregador_id",id);
                o.put("nome",nome);
                o.put("latitude",l.getLatitude());
                o.put("longitude",l.getLongitude());
                o.put("status","online");
                o.put("ultima_atualizacao",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",java.util.Locale.US).format(new java.util.Date()));
                o.put("pedido_atual",pedido.isEmpty()?JSONObject.NULL:pedido);
                o.put("updated_at",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",java.util.Locale.US).format(new java.util.Date()));

                OutputStream os=c.getOutputStream();
                os.write(o.toString().getBytes(StandardCharsets.UTF_8));
                os.close();
                c.getResponseCode();
                c.disconnect();
            } catch(Exception e) {
                updateNotification("🟠 GPS ativo • sem sincronização");
            }
        }).start();
    }

    private Notification notification(String text) {
        Intent open=new Intent(this, MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this,CHANNEL)
                .setContentTitle("Romaneio • Rastreamento")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pi)
                .build();
    }
    private void updateNotification(String text) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,notification(text));
    }
    private void createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Rastreamento GPS",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    @Override public void onDestroy() {
        if(fused!=null && callback!=null) fused.removeLocationUpdates(callback);
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
