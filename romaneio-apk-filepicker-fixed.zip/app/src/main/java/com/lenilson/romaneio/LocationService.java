package com.lenilson.romaneio;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.*;
import android.provider.Settings;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocationService extends Service {
    public static final String ACTION_STOP = "com.lenilson.romaneio.STOP_LOCATION";
    public static final String ACTION_START = "com.lenilson.romaneio.START_LOCATION";
    private static final int NOTIFICATION_ID = 4101;
    private static final String CHANNEL_ID = "romaneio_location";

    // These are the same public Supabase project values used by the web app.
    private static final String SUPABASE_URL = "https://kfjalmwlbgayyogiaanx.supabase.co";
    private static final String SUPABASE_ANON_KEY = "sb_publishable_GXokf74ebXiWSQpv6iuWrg_DfY0cPfH";
    private static final String SUPABASE_TABLE = "entregadores_localizacao";

    private android.location.LocationManager lm;
    private android.location.LocationListener listener;
    private boolean running = false;
    private final ExecutorService network = Executors.newSingleThreadExecutor();

    @Override public void onCreate() {
        super.onCreate();
        lm = (android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            getSharedPreferences("tracking", MODE_PRIVATE).edit().putBoolean("stopped", true).apply();
            stopTracking();
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_START.equals(intent.getAction())) {
            getSharedPreferences("tracking", MODE_PRIVATE).edit().putBoolean("stopped", false).apply();
        }

        // Must call startForeground immediately.
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(NOTIFICATION_ID, notification());
        }
        if (!getSharedPreferences("tracking", MODE_PRIVATE).getBoolean("stopped", false)) {
            startTracking();
        }
        return START_STICKY;
    }

    private void startTracking() {
        if (running) return;

        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }

        try {
            listener = new android.location.LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    saveAndUpload(location);
                }
            };

            lm.requestLocationUpdates(
                android.location.LocationManager.GPS_PROVIDER,
                10000L,
                10f,
                listener,
                Looper.getMainLooper()
            );

            // Network provider helps when GPS is slow/indoors.
            try {
                lm.requestLocationUpdates(
                    android.location.LocationManager.NETWORK_PROVIDER,
                    15000L,
                    25f,
                    listener,
                    Looper.getMainLooper()
                );
            } catch (Exception ignored) {}

            running = true;
        } catch (SecurityException e) {
            stopSelf();
        }
    }

    private void saveAndUpload(Location location) {
        String name = getSharedPreferences("tracking", MODE_PRIVATE).getString("name", "");
        String id = getSharedPreferences("tracking", MODE_PRIVATE).getString("id", "");
        String pedido = getSharedPreferences("tracking", MODE_PRIVATE).getString("pedido", "");

        getSharedPreferences("location", MODE_PRIVATE).edit()
            .putString("lat", String.valueOf(location.getLatitude()))
            .putString("lng", String.valueOf(location.getLongitude()))
            .putLong("time", System.currentTimeMillis())
            .apply();

        if (id.isEmpty()) return;

        final String json = String.format(Locale.US,
            "{\"entregador_id\":\"%s\",\"nome\":\"%s\",\"latitude\":%.8f,\"longitude\":%.8f,\"status\":\"online\",\"ultima_atualizacao\":\"%s\",\"pedido_atual\":%s,\"updated_at\":\"%s\"}",
            jsonEscape(id), jsonEscape(name.isEmpty() ? id : name),
            location.getLatitude(), location.getLongitude(),
            isoNow(),
            pedido.isEmpty() ? "null" : "\"" + jsonEscape(pedido) + "\"",
            isoNow());

        network.submit(() -> upload(json));
    }

    private void upload(String json) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(SUPABASE_URL + "/rest/v1/" + SUPABASE_TABLE + "?on_conflict=entregador_id");
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(12000);
            c.setReadTimeout(12000);
            c.setRequestProperty("apikey", SUPABASE_ANON_KEY);
            c.setRequestProperty("Authorization", "Bearer " + SUPABASE_ANON_KEY);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Prefer", "resolution=merge-duplicates,return=minimal");
            try (OutputStream out = c.getOutputStream()) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            if (code >= 200 && code < 300) {
                getSharedPreferences("location", MODE_PRIVATE).edit()
                    .putLong("lastSync", System.currentTimeMillis()).apply();
            }
        } catch (Exception ignored) {
            // Last GPS fix remains stored locally. Next fix retries synchronization.
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private Notification notification() {
        Intent stop = new Intent(this, LocationService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 77, stop,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 78, open,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);

        b.setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Romaneio — Rastreamento ativo")
            .setContentText("Localização sendo compartilhada")
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true);

        if (Build.VERSION.SDK_INT >= 24) {
            b.addAction(new Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(
                    this, android.R.drawable.ic_menu_close_clear_cancel),
                "PARAR LOCALIZAÇÃO", pi).build());
        }

        return b.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                "Rastreamento de localização",
                NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Rastreamento do entregador do Romaneio");
            ch.setShowBadge(false);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                .createNotificationChannel(ch);
        }
    }

    private void stopTracking() {
        try {
            if (lm != null && listener != null) {
                lm.removeUpdates(listener);
            }
        } catch (Exception ignored) {}
        listener = null;
        running = false;
        stopForeground(true);
        stopSelf();
    }

    private String isoNow() {
        return new java.text.SimpleDateFormat(
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            java.util.Locale.US).format(new java.util.Date());
    }

    private String jsonEscape(String s) {
        return s.replace("\\","\\\\").replace("\"","\\\"")
            .replace("\n","\\n").replace("\r","\\r");
    }

    @Override public void onDestroy() {
        try { if (lm != null && listener != null) lm.removeUpdates(listener); } catch(Exception ignored) {}
        network.shutdownNow();
        running = false;
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
