package com.lenilson.romaneio;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.*;
import android.graphics.Color;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private EditText nome, id, pedido;
    private TextView status;
    private Button start, stop;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.rgb(244,246,248));

        TextView title = new TextView(this);
        title.setText("🏍️  ROMANEIO\nGPS do entregador");
        title.setTextSize(25);
        title.setTextColor(Color.rgb(17,24,39));
        title.setPadding(0,0,0,24);
        root.addView(title);

        nome = field("Nome do entregador", "Ex.: Lenilson");
        id = field("ID do entregador", "Ex.: lenilson01");
        pedido = field("Pedido atual (opcional)", "Ex.: #125");
        root.addView(nome); root.addView(id); root.addView(pedido);

        start = new Button(this);
        start.setText("📍 INICIAR RASTREAMENTO");
        root.addView(start, lp());

        stop = new Button(this);
        stop.setText("■ PARAR RASTREAMENTO");
        stop.setEnabled(false);
        root.addView(stop, lp());

        status = new TextView(this);
        status.setText("Aguardando ativação.");
        status.setTextSize(15);
        status.setTextColor(Color.DKGRAY);
        status.setPadding(0,20,0,0);
        root.addView(status);

        TextView info = new TextView(this);
        info.setText("\nQuando iniciado, o rastreamento continua em segundo plano com uma notificação permanente. Você pode apagar a tela ou sair do app. Para parar, use o botão PARAR.");
        info.setTextSize(14);
        info.setTextColor(Color.DKGRAY);
        root.addView(info);

        setContentView(root);

        start.setOnClickListener(v -> begin());
        stop.setOnClickListener(v -> stopServiceNow());

        if (getIntent().getBooleanExtra("started", false)) {
            start.setEnabled(false);
            stop.setEnabled(true);
        }
    }

    private EditText field(String label, String hint) {
        EditText e = new EditText(this);
        e.setHint(label + " — " + hint);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setPadding(14,14,14,14);
        LinearLayout.LayoutParams p = lp();
        p.setMargins(0,0,0,10);
        e.setLayoutParams(p);
        return e;
    }

    private LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void begin() {
        if (nome.getText().toString().trim().isEmpty() || id.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Informe nome e ID.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
            return;
        }
        Intent i = new Intent(this, LocationService.class);
        i.putExtra("nome", nome.getText().toString().trim());
        i.putExtra("id", id.getText().toString().trim());
        i.putExtra("pedido", pedido.getText().toString().trim());
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        start.setEnabled(false);
        stop.setEnabled(true);
        status.setText("🟢 Rastreamento ativo. Pode sair do app.");
    }

    private void stopServiceNow() {
        stopService(new Intent(this, LocationService.class));
        start.setEnabled(true);
        stop.setEnabled(false);
        status.setText("Rastreamento parado.");
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == 10 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) begin();
        else Toast.makeText(this, "Permita a localização precisa para iniciar.", Toast.LENGTH_LONG).show();
    }
}
