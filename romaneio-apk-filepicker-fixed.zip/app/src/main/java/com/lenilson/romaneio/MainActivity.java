package com.lenilson.romaneio;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 2001;
    private static final int BACKGROUND_LOCATION_REQUEST_CODE = 2002;
    private static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 2003;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    private static final String SITE_URL =
        "https://lenilsonamorim.github.io/Romaneio/Romaneio/Organizador/index.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setGeolocationEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.addJavascriptInterface(new AndroidFileBridge(), "AndroidFilePicker");
        webView.addJavascriptInterface(new AndroidLocationBridge(), "AndroidLocation");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installNativeFilePickerHook(view);
                installNativeLocationHook(view, url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.ms-excel",
                        "text/csv",
                        "text/comma-separated-values",
                        "application/csv"
                });

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback) {

                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {

                    callback.invoke(origin, true, false);
                    return;
                }

                pendingGeoOrigin = origin;
                pendingGeoCallback = callback;

                requestPermissions(
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        },
                        LOCATION_PERMISSION_REQUEST_CODE
                );
            }
        });

        webView.clearCache(true);
        webView.loadUrl(SITE_URL);
        webView.postDelayed(() -> {
            requestNotificationPermissionIfNeeded();
            ensureNativeLocationTracking();
        }, 1200);
    }


    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},
                NOTIFICATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void ensureNativeLocationTracking() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            }, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        // A foreground location service is what keeps GPS alive while the screen is off.
        // Background permission is requested separately on Android 10+ when available.
        startLocationService();
    }

    private void startLocationService() {
        Intent service = new Intent(this, LocationService.class).setAction(LocationService.ACTION_START);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);
    }

    private void installNativeLocationHook(WebView view, String url) {
        String js = "(function(){"
            + "if(!window.AndroidLocation)return;"
            + "try{"
            + "var p=JSON.parse(localStorage.getItem('romaneio_entregador')||'{}');"
            + "if(p.id){window.AndroidLocation.setIdentity(String(p.nome||''),String(p.id||''),String(p.pedido||''));}"
            + "}catch(e){}"
            + "if(!window.__nativeStopHook){"
            + "document.addEventListener('click',function(e){"
            + "var t=e.target;"
            + "if(t&&/parar rastreamento/i.test((t.innerText||''))){"
            + "try{window.AndroidLocation.stop();}catch(x){}"
            + "}"
            + "},true);"
            + "window.__nativeStopHook=true;}"
            + "})();";
        view.evaluateJavascript(js, null);
    }

    private class AndroidLocationBridge {
        @JavascriptInterface
        public void setIdentity(String name, String id, String pedido) {
            getSharedPreferences("tracking", MODE_PRIVATE).edit()
                .putString("name", name == null ? "" : name)
                .putString("id", id == null ? "" : id)
                .putString("pedido", pedido == null ? "" : pedido)
                .putBoolean("stopped", false)
                .apply();
            runOnUiThread(() -> {
                requestNotificationPermissionIfNeeded();
                ensureNativeLocationTracking();
            });
        }

        @JavascriptInterface
        public void stop() {
            Intent service = new Intent(MainActivity.this, LocationService.class)
                .setAction(LocationService.ACTION_STOP);
            startService(service);
        }
    }

    private void installNativeFilePickerHook(WebView view) {
        String js = "(function(){"
            + "window.__nativeFileSelected=function(b64,mime,name){"
            + "try{"
            + "var bin=atob(b64),len=bin.length,bytes=new Uint8Array(len);"
            + "for(var i=0;i<len;i++)bytes[i]=bin.charCodeAt(i);"
            + "var file=new File([bytes],name,{type:mime||'application/octet-stream',lastModified:Date.now()});"
            + "var input=document.getElementById('file');"
            + "if(!input){return false;}"
            + "var dt=new DataTransfer();dt.items.add(file);input.files=dt.files;"
            + "input.dispatchEvent(new Event('change',{bubbles:true}));"
            + "return true;"
            + "}catch(e){console.error('Native file bridge',e);return false;}"
            + "};"
            + "if(!window.__nativeFileHookInstalled){"
            + "document.addEventListener('click',function(e){"
            + "var t=e.target;"
            + "var label=t&&t.closest?t.closest('label[for=\\\"file\\\"]'):null;"
            + "if(label){e.preventDefault();e.stopPropagation();window.AndroidFilePicker.openFilePicker();}"
            + "},true);"
            + "window.__nativeFileHookInstalled=true;}"
            + "})();";
        view.evaluateJavascript(js, null);
    }

    private class AndroidFileBridge {
        @JavascriptInterface
        public void openFilePicker() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.ms-excel",
                        "text/csv",
                        "text/comma-separated-values",
                        "application/csv"
                });
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (ActivityNotFoundException ignored) {
                }
            });
        }
    }

    private void deliverNativeFileToWeb(Uri uri) {
        try {
            String name = "planilha";
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "application/octet-stream";

            String[] projection = {android.provider.OpenableColumns.DISPLAY_NAME};
            try (android.database.Cursor cursor =
                         getContentResolver().query(uri, projection, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(
                            android.provider.OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0 && cursor.getString(idx) != null) {
                        name = cursor.getString(idx);
                    }
                }
            }

            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return;

                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer, 0, n);
                }

                String b64 = Base64.encodeToString(
                        out.toByteArray(), Base64.NO_WRAP);

                String js = "window.__nativeFileSelected(" +
                        "'" + escapeJs(b64) + "'," +
                        "'" + escapeJs(mime) + "'," +
                        "'" + escapeJs(name) + "')";

                webView.post(() ->
                        webView.evaluateJavascript(js, null));
            }
        } catch (Exception e) {
            webView.post(() ->
                    webView.evaluateJavascript(
                            "console.error('Falha ao abrir planilha nativa')",
                            null));
        }
    }

    private String escapeJs(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            boolean granted = false;
            for (int result : grantResults) {
                if (result == PackageManager.PERMISSION_GRANTED) {
                    granted = true;
                    break;
                }
            }

            if (pendingGeoCallback != null && pendingGeoOrigin != null) {
                pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            }

            pendingGeoCallback = null;
            pendingGeoOrigin = null;

            if (granted) {
                requestNotificationPermissionIfNeeded();
                startLocationService();
            }
        }
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {

            if (resultCode == RESULT_OK &&
                    data != null &&
                    data.getData() != null) {

                Uri uri = data.getData();

                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(
                            new Uri[]{uri});
                    filePathCallback = null;
                }

                deliverNativeFileToWeb(uri);

            } else if (filePathCallback != null) {

                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
            }
        }

        super.onActivityResult(
                requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
