package com.lenilson.romaneio;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private static final String SITE_URL =
        "https://lenilsonamorim.github.io/Romaneio/Romaneio/Organizador/index.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Native bridge: guarantees that the Android document picker can be
        // opened even when WebView's HTML file chooser is not triggered.
        webView.addJavascriptInterface(new AndroidFileBridge(), "AndroidFilePicker");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installNativeFilePickerHook(view);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.ms-excel",
                        "text/csv",
                        "text/comma-separated-values",
                        "application/csv"
                });

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl(SITE_URL);
    }

    private void installNativeFilePickerHook(WebView view) {
        String js = "(function(){"
            + "window.__nativeFileSelected=function(b64,mime,name){"
            + "try{"
            + "var bin=atob(b64),len=bin.length,bytes=new Uint8Array(len);"
            + "for(var i=0;i<len;i++)bytes[i]=bin.charCodeAt(i);"
            + "var file=new File([bytes],name,{type:mime||'application/octet-stream',lastModified:Date.now()});"
            + "var input=document.getElementById('file');"
            + "if(!input){return false;}"
            + "var dt=new DataTransfer();dt.items.add(file);input.files=dt.files;"
            + "input.dispatchEvent(new Event('change',{bubbles:true}));"
            + "return true;"
            + "}catch(e){console.error('Native file bridge',e);return false;}"
            + "};"
            + "if(!window.__nativeFileHookInstalled){"
            + "document.addEventListener('click',function(e){"
            + "var t=e.target;"
            + "var label=t&&t.closest?t.closest('label[for=\\\"file\\\"]'):null;"
            + "if(label){e.preventDefault();e.stopPropagation();window.AndroidFilePicker.openFilePicker();}"
            + "},true);"
            + "window.__nativeFileHookInstalled=true;}"
            + "})();";
        view.evaluateJavascript(js, null);
    }

    private class AndroidFileBridge {
        @JavascriptInterface
        public void openFilePicker() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.ms-excel",
                        "text/csv",
                        "text/comma-separated-values",
                        "application/csv"
                });
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (ActivityNotFoundException ignored) {
                }
            });
        }
    }

    private void deliverNativeFileToWeb(Uri uri) {
        try {
            String name = "planilha";
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "application/octet-stream";

            String[] projection = {android.provider.OpenableColumns.DISPLAY_NAME};
            try (android.database.Cursor cursor = getContentResolver().query(uri, projection, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0 && cursor.getString(idx) != null) name = cursor.getString(idx);
                }
            }

            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return;
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                String js = "window.__nativeFileSelected(" +
                        "'" + escapeJs(b64) + "'," +
                        "'" + escapeJs(mime) + "'," +
                        "'" + escapeJs(name) + "')";
                webView.post(() -> webView.evaluateJavascript(js, null));
            }
        } catch (Exception e) {
            webView.post(() -> webView.evaluateJavascript("console.error('Falha ao abrir planilha nativa')", null));
        }
    }

    private String escapeJs(String value) {
        return value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "\\r");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                // If WebView itself opened the picker, complete its callback.
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(new Uri[]{uri});
                    filePathCallback = null;
                }
                // Also inject the actual File into the page for the native bridge path.
                deliverNativeFileToWeb(uri);
            } else if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
