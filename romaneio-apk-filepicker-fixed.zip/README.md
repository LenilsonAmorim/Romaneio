# Romaneio APK — GPS

Versão preparada para permitir que a página do Romaneio use a localização do Android dentro do WebView.

Alterações:
- ACCESS_FINE_LOCATION
- ACCESS_COARSE_LOCATION
- WebView com geolocation habilitada
- Solicitação de permissão de localização em tempo de execução
- Liberação da geolocalização para a página HTTPS do Romaneio
- Mantido o seletor nativo de planilhas

Observação:
Esta versão resolve a permissão GPS do WebView. Rastreamento contínuo com tela bloqueada/segundo plano ainda requer um serviço de localização em primeiro plano (Foreground Service) nativo no Android.
