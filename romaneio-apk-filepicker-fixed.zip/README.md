# Romaneio APK

Build source for the Romaneio Android WebView APK.

This version keeps the same workflow input filename: `romaneio-apk.zip`.
The WebView includes Android's file chooser bridge so `<input type="file">`
opens the device document picker for XLS/XLSX/CSV files.
